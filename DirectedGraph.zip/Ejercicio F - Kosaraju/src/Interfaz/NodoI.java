package Interfaz;
import Implementacion.Nodo;

public interface NodoI {
    public void setInfo(String info);
    public String getInfo();
}
